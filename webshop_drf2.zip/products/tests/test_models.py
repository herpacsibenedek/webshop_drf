from django.test import TestCase

#Test Models here


